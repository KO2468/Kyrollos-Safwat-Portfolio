-- Run after 01_retail_lab_setup.sql.
-- Every orphan count and reconciliation difference should be zero.

SELECT 'departments' AS table_name, COUNT(*) AS row_count FROM departments
UNION ALL SELECT 'employees', COUNT(*) FROM employees
UNION ALL SELECT 'customers', COUNT(*) FROM customers
UNION ALL SELECT 'suppliers', COUNT(*) FROM suppliers
UNION ALL SELECT 'categories', COUNT(*) FROM categories
UNION ALL SELECT 'products', COUNT(*) FROM products
UNION ALL SELECT 'shippers', COUNT(*) FROM shippers
UNION ALL SELECT 'orders', COUNT(*) FROM orders
UNION ALL SELECT 'order_items', COUNT(*) FROM order_items
UNION ALL SELECT 'payments', COUNT(*) FROM payments
UNION ALL SELECT 'shipments', COUNT(*) FROM shipments
ORDER BY table_name;

SELECT 'orders_without_customer' AS check_name, COUNT(*) AS issue_count
FROM orders o LEFT JOIN customers c ON c.customer_id = o.customer_id
WHERE c.customer_id IS NULL
UNION ALL
SELECT 'order_items_without_order', COUNT(*)
FROM order_items oi LEFT JOIN orders o ON o.order_id = oi.order_id
WHERE o.order_id IS NULL
UNION ALL
SELECT 'order_items_without_product', COUNT(*)
FROM order_items oi LEFT JOIN products p ON p.product_id = oi.product_id
WHERE p.product_id IS NULL
UNION ALL
SELECT 'payments_without_order', COUNT(*)
FROM payments p LEFT JOIN orders o ON o.order_id = p.order_id
WHERE o.order_id IS NULL
UNION ALL
SELECT 'shipments_without_order', COUNT(*)
FROM shipments s LEFT JOIN orders o ON o.order_id = s.order_id
WHERE o.order_id IS NULL;

WITH order_totals AS (
    SELECT order_id,
           ROUND(SUM(quantity * unit_price * (1 - discount_pct)), 2) AS order_total
    FROM order_items
    GROUP BY order_id
), successful_payments AS (
    SELECT order_id, ROUND(SUM(amount), 2) AS paid_total
    FROM payments
    WHERE payment_status = 'successful'
    GROUP BY order_id
)
SELECT COUNT(*) AS paid_order_reconciliation_issues
FROM orders o
JOIN order_totals ot ON ot.order_id = o.order_id
JOIN successful_payments sp ON sp.order_id = o.order_id
WHERE o.status IN ('completed', 'shipped', 'returned')
  AND ABS(ot.order_total - sp.paid_total) > 0.01;

SELECT 'customers_without_orders' AS edge_case, COUNT(*) AS row_count
FROM customers c LEFT JOIN orders o ON o.customer_id = c.customer_id
WHERE o.order_id IS NULL
UNION ALL
SELECT 'products_never_ordered', COUNT(*)
FROM products p LEFT JOIN order_items oi ON oi.product_id = p.product_id
WHERE oi.order_id IS NULL
UNION ALL
SELECT 'departments_without_employees', COUNT(*)
FROM departments d LEFT JOIN employees e ON e.department_id = d.department_id
WHERE e.employee_id IS NULL
UNION ALL
SELECT 'employees_without_department', COUNT(*)
FROM employees WHERE department_id IS NULL
UNION ALL
SELECT 'suppliers_without_products', COUNT(*)
FROM suppliers s LEFT JOIN products p ON p.supplier_id = s.supplier_id
WHERE p.product_id IS NULL
UNION ALL
SELECT 'products_without_supplier', COUNT(*)
FROM products WHERE supplier_id IS NULL;
