-- Exercise 01
SELECT customer_id, customer_name, city, signup_date
FROM customers
WHERE segment = 'Corporate'
  AND country = 'Egypt'
ORDER BY signup_date DESC, customer_id;

-- Exercise 02
SELECT product_id, product_name, unit_price, stock_quantity
FROM products
WHERE discontinued <> TRUE
  AND stock_quantity > 0
  AND unit_price BETWEEN 50 AND 300
ORDER BY unit_price DESC, product_id;

-- Exercise 03
SELECT employee_id, first_name, last_name, hire_date, job_title, salary
FROM employees
WHERE hire_date >= '2021-01-01'
  AND salary BETWEEN 55000 AND 80000
ORDER BY salary DESC;

-- Exercise 04
SELECT order_id, order_date, status, sales_channel, shipping_country
FROM orders
WHERE order_date >= '2025-01-01'
  AND order_date < '2025-04-01'
  AND status <> 'cancelled'
ORDER BY order_date;

-- Exercise 05
SELECT DISTINCT country, city
FROM customers
WHERE segment = 'Corporate'
   OR segment = 'Small Business'
ORDER BY country, city;

-- Exercise 06
SELECT product_id, product_name, unit_price
FROM products
WHERE LOWER(product_name) LIKE '%pro%'
ORDER BY product_name;

-- Exercise 07
SELECT customer_id, customer_name, segment, signup_date
FROM customers
WHERE referred_by_customer_id IS NULL
ORDER BY customer_id;

-- Exercise 08
SELECT order_id, order_date, status, sales_channel, shipping_country
FROM orders
WHERE order_date >= '2025-01-01'
  AND order_date < '2026-01-01'
  AND shipping_country IN ('Saudi Arabia', 'United Arab Emirates')
  AND status IN ('completed', 'shipped')
  AND sales_channel NOT IN ('Retail');

-- Exercise 09
SELECT product_id, product_name, stock_quantity, discontinued
FROM products
WHERE stock_quantity = 0
   OR discontinued = TRUE
ORDER BY discontinued DESC, product_id;

-- Exercise 10
SELECT product_id, product_name, unit_price
FROM products
WHERE discontinued = FALSE
ORDER BY unit_price DESC, product_id
LIMIT 5;

-- Exercise 11
SELECT status, COUNT(*) AS order_count
FROM orders
GROUP BY status
ORDER BY order_count DESC;

-- Exercise 12
SELECT country, segment, COUNT(*) AS customer_count
FROM customers
GROUP BY country, segment
HAVING COUNT(*) >= 3
ORDER BY country, segment;

-- Exercise 13
SELECT
    category_id,
    COUNT(*) AS product_count,
    ROUND(AVG(unit_price), 2) AS average_price,
    MIN(unit_price) AS minimum_price,
    MAX(unit_price) AS maximum_price
FROM products
GROUP BY category_id
HAVING COUNT(*) >= 2
ORDER BY category_id;

-- Exercise 14
SELECT
    TO_CHAR(order_date, 'YYYY-MM') AS order_month,
    COUNT(*) AS order_count
FROM orders
GROUP BY TO_CHAR(order_date, 'YYYY-MM')
ORDER BY order_month;

-- Exercise 15
SELECT
    COALESCE(department_id, 0) AS department_id,
    COUNT(*) AS headcount,
    ROUND(AVG(salary), 2) AS average_salary,
    MIN(salary) AS minimum_salary,
    MAX(salary) AS maximum_salary
FROM employees
GROUP BY COALESCE(department_id, 0)
ORDER BY department_id;

-- Exercise 16
SELECT
    order_id,
    COUNT(DISTINCT product_id) AS distinct_products,
    SUM(quantity) AS total_units,
    SUM(quantity * unit_price * (1 - discount_pct)) AS net_order_value
FROM order_items
GROUP BY order_id
ORDER BY net_order_value DESC;

-- Exercise 17
SELECT
    order_id,
    COUNT(*) AS line_count,
    SUM(quantity * unit_price * (1 - discount_pct)) AS net_order_value
FROM order_items
GROUP BY order_id
HAVING COUNT(*) >= 3
   AND SUM(quantity * unit_price * (1 - discount_pct)) > 1000
ORDER BY net_order_value DESC;

-- Exercise 18
SELECT
    COALESCE(supplier_id, 0) AS supplier_id,
    COUNT(*) AS total_products,
    COUNT(*) FILTER (WHERE discontinued = FALSE) AS active_products,
    COUNT(*) FILTER (WHERE discontinued = TRUE) AS discontinued_products
FROM products
GROUP BY COALESCE(supplier_id, 0)
HAVING COUNT(*) >= 2
ORDER BY supplier_id;

-- Exercise 19
SELECT
    o.order_id,
    o.order_date,
    c.customer_name,
    c.segment,
    o.shipping_country
FROM orders o
INNER JOIN customers c
    ON o.customer_id = c.customer_id
WHERE o.status = 'completed'
  AND o.order_date >= '2025-01-01'
  AND o.order_date < '2026-01-01'
ORDER BY o.order_date, o.order_id;

-- Exercise 20
SELECT
    o.order_id,
    o.order_date,
    p.product_name,
    oi.quantity,
    oi.unit_price,
    oi.discount_pct,
    oi.quantity * oi.unit_price * (1 - oi.discount_pct) AS net_line_value
FROM orders o
INNER JOIN order_items oi
    ON o.order_id = oi.order_id
INNER JOIN products p
    ON oi.product_id = p.product_id
WHERE o.status = 'returned'
ORDER BY o.order_id, p.product_name;

-- Exercise 21
SELECT
    o.order_id,
    o.order_date,
    c.customer_name,
    COALESCE(
        e.first_name || ' ' || e.last_name,
        'Unassigned / Online'
    ) AS sales_rep_name,
    o.sales_channel
FROM orders o
INNER JOIN customers c
    ON o.customer_id = c.customer_id
LEFT JOIN employees e
    ON o.sales_rep_id = e.employee_id
ORDER BY o.order_id;

-- Exercise 22
SELECT
    c.customer_id,
    c.customer_name,
    c.country,
    c.segment
FROM customers c
LEFT JOIN orders o
    ON c.customer_id = o.customer_id
WHERE o.order_id IS NULL
ORDER BY c.customer_id;

-- Exercise 23
SELECT
    p.product_id,
    p.product_name,
    p.unit_price,
    p.discontinued,
    p.stock_quantity
FROM products p
LEFT JOIN order_items oi
    ON p.product_id = oi.product_id
WHERE oi.product_id IS NULL
ORDER BY p.product_id;

-- Exercise 24
SELECT
    d.department_id,
    d.department_name,
    COUNT(e.employee_id) AS headcount,
    COALESCE(ROUND(AVG(e.salary), 2), 0) AS average_salary
FROM departments d
LEFT JOIN employees e
    ON d.department_id = e.department_id
GROUP BY d.department_id, d.department_name
ORDER BY d.department_id;

-- Exercise 25
SELECT
    e.employee_id,
    e.first_name || ' ' || e.last_name AS employee_name,
    COALESCE(d.department_name, 'No Department') AS department_name,
    e.job_title
FROM departments d
RIGHT JOIN employees e
    ON d.department_id = e.department_id
ORDER BY e.employee_id;

-- Exercise 26
SELECT
    s.supplier_id,
    s.supplier_name,
    p.product_id,
    p.product_name
FROM suppliers s
FULL OUTER JOIN products p
    ON s.supplier_id = p.supplier_id
WHERE s.supplier_id IS NULL
   OR p.product_id IS NULL
ORDER BY s.supplier_id, p.product_id;

-- Exercise 27
SELECT
    e.employee_id,
    e.first_name || ' ' || e.last_name AS employee_name,
    e.job_title,
    COALESCE(
        m.first_name || ' ' || m.last_name,
        'Top Level'
    ) AS manager_name
FROM employees e
LEFT JOIN employees m
    ON e.manager_id = m.employee_id
ORDER BY e.employee_id;

-- Exercise 28
SELECT
    c.category_name,
    COALESCE(p.category_name, 'Top Level') AS parent_category_name
FROM categories c
LEFT JOIN categories p
    ON c.parent_category_id = p.category_id
ORDER BY c.category_name;

-- Exercise 29
SELECT
    c.customer_id,
    c.customer_name,
    r.customer_id AS referrer_id,
    r.customer_name AS referrer_name
FROM customers c
INNER JOIN customers r
    ON c.referred_by_customer_id = r.customer_id
ORDER BY c.customer_id;

-- Exercise 30
SELECT DISTINCT
    c.country,
    s.shipper_name
FROM customers c
CROSS JOIN shippers s
ORDER BY c.country, s.shipper_name;

-- Exercise 31
SELECT
    o.order_id,
    o.order_date,
    o.status,
    o.customer_id
FROM orders o
LEFT JOIN payments p
    ON o.order_id = p.order_id
WHERE p.order_id IS NULL
ORDER BY o.order_id;

-- Exercise 32
SELECT
    o.order_id,
    s.shipment_id,
    sh.shipper_name,
    o.required_date,
    s.delivered_date,
    s.delivered_date - o.required_date AS days_late
FROM orders o
INNER JOIN shipments s
    ON o.order_id = s.order_id
INNER JOIN shippers sh
    ON s.shipper_id = sh.shipper_id
WHERE s.delivered_date > o.required_date
ORDER BY days_late DESC, o.order_id;

-- Exercise 33
SELECT
    c.country,
    COUNT(DISTINCT o.order_id) AS order_count,
    SUM(oi.quantity) AS total_units,
    SUM(oi.quantity * oi.unit_price * (1 - oi.discount_pct)) AS revenue
FROM customers c
INNER JOIN orders o
    ON c.customer_id = o.customer_id
INNER JOIN order_items oi
    ON o.order_id = oi.order_id
WHERE o.status IN ('completed', 'shipped')
GROUP BY c.country
HAVING SUM(oi.quantity * oi.unit_price * (1 - oi.discount_pct)) > 20000
ORDER BY revenue DESC, c.country;

-- Exercise 34
SELECT
    c.customer_id,
    c.customer_name,
    COUNT(DISTINCT o.order_id) AS eligible_order_count,
    SUM(oi.quantity * oi.unit_price * (1 - oi.discount_pct)) AS lifetime_spend
FROM customers c
INNER JOIN orders o
    ON c.customer_id = o.customer_id
INNER JOIN order_items oi
    ON o.order_id = oi.order_id
WHERE o.status IN ('completed', 'shipped')
GROUP BY c.customer_id, c.customer_name
HAVING SUM(oi.quantity * oi.unit_price * (1 - oi.discount_pct)) > 5000
ORDER BY lifetime_spend DESC, c.customer_id;

-- Exercise 35
SELECT
    p.product_id,
    p.product_name,
    SUM(oi.quantity) AS units_sold,
    SUM(oi.quantity * oi.unit_price * (1 - oi.discount_pct)) AS revenue
FROM products p
INNER JOIN order_items oi
    ON p.product_id = oi.product_id
INNER JOIN orders o
    ON oi.order_id = o.order_id
WHERE o.status IN ('completed', 'shipped')
GROUP BY p.product_id, p.product_name
HAVING SUM(oi.quantity) >= 20
ORDER BY units_sold DESC, p.product_id;

-- Exercise 36
SELECT
    e.employee_id,
    e.first_name || ' ' || e.last_name AS employee_name,
    COUNT(DISTINCT o.order_id) AS completed_or_shipped_orders,
    COALESCE(
        SUM(oi.quantity * oi.unit_price * (1 - oi.discount_pct)),
        0
    ) AS revenue
FROM employees e
INNER JOIN departments d
    ON e.department_id = d.department_id
LEFT JOIN orders o
    ON e.employee_id = o.sales_rep_id
   AND o.status IN ('completed', 'shipped')
LEFT JOIN order_items oi
    ON o.order_id = oi.order_id
WHERE d.department_name = 'Sales'
GROUP BY e.employee_id, e.first_name, e.last_name
ORDER BY e.employee_id;

-- Exercise 37
SELECT
    c.category_name,
    SUM(oi.quantity * oi.unit_price * (1 - oi.discount_pct)) AS revenue,
    SUM(
        oi.quantity * oi.unit_price * (1 - oi.discount_pct)
        - oi.quantity * p.unit_cost
    ) AS gross_profit
FROM categories c
INNER JOIN products p
    ON c.category_id = p.category_id
INNER JOIN order_items oi
    ON p.product_id = oi.product_id
INNER JOIN orders o
    ON oi.order_id = o.order_id
WHERE c.category_id NOT IN (
    SELECT parent_category_id
    FROM categories
    WHERE parent_category_id IS NOT NULL
)
AND o.status IN ('completed', 'shipped')
GROUP BY c.category_id, c.category_name
HAVING SUM(oi.quantity * oi.unit_price * (1 - oi.discount_pct)) > 10000
ORDER BY revenue DESC;

-- Exercise 38
SELECT
    s.supplier_id,
    s.supplier_name,
    COUNT(p.product_id) AS active_product_count
FROM suppliers s
LEFT JOIN products p
    ON s.supplier_id = p.supplier_id
   AND p.discontinued = FALSE
GROUP BY s.supplier_id, s.supplier_name
HAVING COUNT(p.product_id) >= 3
ORDER BY active_product_count DESC, s.supplier_id;

-- Exercise 39
SELECT
    c.customer_id,
    c.customer_name,
    COUNT(DISTINCT p.category_id) AS category_count,
    SUM(oi.quantity * oi.unit_price * (1 - oi.discount_pct)) AS recognized_revenue
FROM customers c
INNER JOIN orders o
    ON c.customer_id = o.customer_id
INNER JOIN order_items oi
    ON o.order_id = oi.order_id
INNER JOIN products p
    ON oi.product_id = p.product_id
WHERE o.status IN ('completed', 'shipped')
GROUP BY c.customer_id, c.customer_name
HAVING COUNT(DISTINCT p.category_id) >= 3
ORDER BY category_count DESC, c.customer_id;

-- Exercise 40
SELECT
    c.country,
    COUNT(DISTINCT o.order_id) AS order_count,
    SUM(oi.quantity * oi.unit_price * (1 - oi.discount_pct)) AS revenue,
    ROUND(
        SUM(oi.quantity * oi.unit_price * (1 - oi.discount_pct))
        / COUNT(DISTINCT o.order_id),
        2
    ) AS average_order_value
FROM customers c
INNER JOIN orders o
    ON c.customer_id = o.customer_id
INNER JOIN order_items oi
    ON o.order_id = oi.order_id
WHERE o.status IN ('completed', 'shipped')
GROUP BY c.country
HAVING COUNT(DISTINCT o.order_id) >= 5
ORDER BY average_order_value DESC, c.country;

-- Exercise 41
SELECT
    product_id,
    product_name,
    unit_price
FROM products
WHERE discontinued = FALSE
  AND unit_price > (
      SELECT AVG(unit_price)
      FROM products
      WHERE discontinued = FALSE
  )
ORDER BY unit_price DESC, product_id;

-- Exercise 42
SELECT
    e.employee_id,
    e.first_name || ' ' || e.last_name AS employee_name,
    e.department_id,
    e.salary
FROM employees e
WHERE e.department_id IS NOT NULL
  AND e.salary > (
      SELECT AVG(e2.salary)
      FROM employees e2
      WHERE e2.department_id = e.department_id
  )
ORDER BY e.department_id, e.salary DESC;

-- Exercise 43
SELECT
    c.customer_id,
    c.customer_name,
    c.country,
    c.segment
FROM customers c
WHERE EXISTS (
    SELECT 1
    FROM orders o
    WHERE o.customer_id = c.customer_id
      AND o.status = 'completed'
      AND o.order_date >= '2025-01-01'
      AND o.order_date < '2026-01-01'
)
ORDER BY c.customer_id;

-- Exercise 44
SELECT
    c.customer_id,
    c.customer_name,
    c.country,
    c.segment
FROM customers c
WHERE NOT EXISTS (
    SELECT 1
    FROM orders o
    WHERE o.customer_id = c.customer_id
)
ORDER BY c.customer_id;

-- Exercise 45
SELECT
    p.product_id,
    p.product_name,
    p.unit_price,
    p.stock_quantity
FROM products p
WHERE p.discontinued = FALSE
  AND NOT EXISTS (
      SELECT 1
      FROM order_items oi
      WHERE oi.product_id = p.product_id
  )
ORDER BY p.product_id;

-- Exercise 46
WITH order_values AS (
    SELECT
        order_id,
        SUM(quantity * unit_price * (1 - discount_pct)) AS net_order_value
    FROM order_items
    GROUP BY order_id
)
SELECT
    order_id,
    net_order_value
FROM order_values
WHERE net_order_value > (
    SELECT AVG(net_order_value)
    FROM order_values
)
ORDER BY net_order_value DESC, order_id;

-- Exercise 47
WITH customer_spend AS (
    SELECT
        c.customer_id,
        c.customer_name,
        SUM(
            oi.quantity * oi.unit_price * (1 - oi.discount_pct)
        ) AS lifetime_spend
    FROM customers c
    INNER JOIN orders o
        ON c.customer_id = o.customer_id
    INNER JOIN order_items oi
        ON o.order_id = oi.order_id
    WHERE o.status IN ('completed', 'shipped')
    GROUP BY c.customer_id, c.customer_name
)
SELECT
    customer_id,
    customer_name,
    lifetime_spend
FROM customer_spend
WHERE lifetime_spend > (
    SELECT AVG(lifetime_spend)
    FROM customer_spend
)
ORDER BY lifetime_spend DESC, customer_id;

-- Exercise 48
SELECT
    e.department_id,
    e.employee_id,
    e.first_name || ' ' || e.last_name AS employee_name,
    e.salary
FROM employees e
WHERE e.department_id IS NOT NULL
  AND e.salary = (
      SELECT MAX(e2.salary)
      FROM employees e2
      WHERE e2.department_id = e.department_id
  )
ORDER BY e.department_id, e.employee_id;

-- Exercise 49
SELECT
    p.product_id,
    p.product_name
FROM products p
WHERE EXISTS (
    SELECT 1
    FROM order_items oi
    INNER JOIN orders o
        ON oi.order_id = o.order_id
    INNER JOIN customers c
        ON o.customer_id = c.customer_id
    WHERE oi.product_id = p.product_id
      AND o.status IN ('completed', 'shipped')
      AND c.segment = 'Corporate'
)
AND EXISTS (
    SELECT 1
    FROM order_items oi
    INNER JOIN orders o
        ON oi.order_id = o.order_id
    INNER JOIN customers c
        ON o.customer_id = c.customer_id
    WHERE oi.product_id = p.product_id
      AND o.status IN ('completed', 'shipped')
      AND c.segment = 'Consumer'
)
ORDER BY p.product_id;

-- Exercise 50
WITH product_revenue AS (
    SELECT
        p.category_id,
        p.product_id,
        p.product_name,
        SUM(
            oi.quantity * oi.unit_price * (1 - oi.discount_pct)
        ) AS product_revenue
    FROM products p
    INNER JOIN order_items oi
        ON p.product_id = oi.product_id
    INNER JOIN orders o
        ON oi.order_id = o.order_id
    WHERE o.status IN ('completed', 'shipped')
    GROUP BY p.category_id, p.product_id, p.product_name
)
SELECT
    c.category_name,
    pr.product_id,
    pr.product_name,
    pr.product_revenue
FROM product_revenue pr
INNER JOIN categories c
    ON pr.category_id = c.category_id
WHERE pr.product_revenue = (
    SELECT MAX(pr2.product_revenue)
    FROM product_revenue pr2
    WHERE pr2.category_id = pr.category_id
)
ORDER BY c.category_name, pr.product_id;